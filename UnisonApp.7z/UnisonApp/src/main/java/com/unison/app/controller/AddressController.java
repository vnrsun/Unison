package com.unison.app.controller;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.unison.app.TO.AddressTO;
import com.unison.app.service.AddressService;

@RestController
@RequestMapping("/address")
public class AddressController {

	@Autowired
	private AddressService addressService;

	@PostMapping("/save")
	public void saveOrUpdateAdress(@RequestBody AddressTO addressTO)
			throws Exception {
		 addressService.saveAddress(addressTO);
	}
	
	@PostMapping("/delete")
	public void deleteAddress(@RequestBody Integer addressId)
			throws Exception {
		 addressService.deleteAddress(addressId);
	}
	
	@PostMapping("/fetch")
	public void fetchAddress(@RequestBody Integer addressId)
			throws Exception {
		 addressService.fetchAddress(addressId);
	}
	

}
