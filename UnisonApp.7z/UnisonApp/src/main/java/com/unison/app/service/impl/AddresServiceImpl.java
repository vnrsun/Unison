package com.unison.app.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.unison.app.TO.AddressMapper;
import com.unison.app.TO.AddressTO;
import com.unison.app.service.AddressService;
import com.unison.model.Address;
import com.unison.repository.AddressRepository;
@Service
public class AddresServiceImpl  implements AddressService{

	@Autowired
	private AddressRepository addressRepository;
	
	@Autowired
	private AddressMapper addressMapper;
	
	
	
	@Override
	public AddressTO fetchAddress(Integer addressId) {
		addressRepository.findById(addressId);
		return null;
	}

	@Override
	public void deleteAddress(Integer addressId) {
	
		addressRepository.deleteByaddressd(addressId);
	}

	@Override
	public void saveAddress(AddressTO addressTO) {
	     Address address = addressMapper.addressTOAddress(addressTO);
		addressRepository.save(address);
	}

}
