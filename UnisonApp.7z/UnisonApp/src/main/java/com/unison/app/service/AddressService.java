package com.unison.app.service;

import org.springframework.stereotype.Service;

import com.unison.app.TO.AddressTO;
@Service
public interface AddressService{

	public AddressTO fetchAddress(Integer addressId);

	public void deleteAddress(Integer addressId);
	
	public void saveAddress(AddressTO addressTO); 

}
