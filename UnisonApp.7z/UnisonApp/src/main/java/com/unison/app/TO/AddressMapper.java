package com.unison.app.TO;

import org.mapstruct.Mapper;

import com.unison.model.Address;

@Mapper(componentModel = "spring")
public interface AddressMapper {
	Address addressTOAddress(AddressTO addressTO);
	AddressTO addressToAddressTO(Address address);
}
