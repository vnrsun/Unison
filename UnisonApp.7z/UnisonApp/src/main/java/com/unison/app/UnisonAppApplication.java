package com.unison.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnisonAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnisonAppApplication.class, args);
	}

}
