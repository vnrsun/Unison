package com.unison.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AddressRepository extends JpaRepository<com.unison.model.Address, Integer> {
	public void deleteByaddressd(Integer addressd);
	public void findByaddressd(Integer addressd);
}
