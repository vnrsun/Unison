package com.unison.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnisonAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
